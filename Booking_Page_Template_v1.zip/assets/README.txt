Place the Safe Insight logo here as safe-insight-logo.png. The prior Safe Insight project references this filename.
