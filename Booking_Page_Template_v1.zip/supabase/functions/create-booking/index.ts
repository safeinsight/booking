import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "../_shared/cors.ts";
import { getAccessToken, listEvents, createEvent } from "../_shared/google.ts";

const sb = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

function overlaps(aStart:string,aEnd:string,bStart:string,bEnd:string) {
  return new Date(aStart) < new Date(bEnd) && new Date(aEnd) > new Date(bStart);
}

function splitSlots(start:string,end:string,minutes:number) {
  const out:any[]=[];
  let cursor=new Date(start), finish=new Date(end);
  while(cursor<finish) {
    const next=new Date(cursor.getTime()+minutes*60000);
    if(next>finish) throw new Error("Booking duration is not aligned to the location's slot length.");
    out.push({slot_start:cursor.toISOString(),slot_end:next.toISOString()});
    cursor=next;
  }
  return out;
}

Deno.serve(async req => {
  if(req.method==="OPTIONS") return new Response("ok",{headers:corsHeaders});

  try {
    const body=await req.json();
    const {location_slug,start_time,end_time,student}=body;
    if(!location_slug||!start_time||!end_time||!student?.fullName||!student?.phone||!student?.email)
      throw new Error("Complete booking information is required.");

    const {data:loc,error:le}=await sb.from("locations").select("*")
      .eq("slug",location_slug).eq("active",true).single();
    if(le||!loc) throw new Error("Location not found.");

    const start=new Date(start_time), end=new Date(end_time), now=new Date();
    if(end<=start) throw new Error("Invalid booking duration.");
    if(start.getTime()-now.getTime() < loc.minimum_booking_notice_hours*3600000)
      throw new Error(`Bookings must be made at least ${loc.minimum_booking_notice_hours} hours in advance.`);

    const horizon=new Date(now.getTime()+loc.booking_horizon_days*86400000);
    if(start>horizon) throw new Error("This appointment is outside the booking window.");

    const slots=splitSlots(start.toISOString(),end.toISOString(),loc.appointment_length_minutes);

    // Final capacity check inside the backend immediately before creating the booking.
    const {data:existing}=await sb.from("booking_slots")
      .select("slot_start,booking_id,bookings!inner(status)")
      .eq("location_id",loc.id)
      .in("bookings.status",["pending","confirmed","rescheduled"]);

    for(const requested of slots) {
      const count=(existing||[]).filter(x => x.slot_start===requested.slot_start).length;
      if(count>=loc.max_students_per_slot)
        throw new Error(`The ${new Intl.DateTimeFormat("en-US",{hour:"numeric",minute:"2-digit"}).format(start)} slot is full.`);
    }

    // Final Google Calendar blocking-event check.
    const {data:gc}=await sb.from("google_calendar_connections")
      .select("google_calendar_id,refresh_token").eq("location_id",loc.id).maybeSingle();

    let googleEvent:any=null;
    if(gc) {
      const token=await getAccessToken(gc.refresh_token);
      const events=await listEvents(token,gc.google_calendar_id,start.toISOString(),end.toISOString());
      const blocking=events.find(e => !e.extendedProperties?.private?.booking_id &&
        e.start?.dateTime && e.end?.dateTime &&
        overlaps(start.toISOString(),end.toISOString(),e.start.dateTime,e.end.dateTime));
      if(blocking) throw new Error("That time is blocked on the location's Google Calendar.");

      // Create one event for the whole contiguous booking.
      googleEvent=await createEvent(token,gc.google_calendar_id,{
        summary:`Booking – ${student.fullName}`,
        location:loc.address || undefined,
        description:[
          `Booking ID will be added after database creation.`,
          `Student: ${student.fullName}`,
          `Phone: ${student.phone}`,
          `Email: ${student.email}`
        ].join("\n"),
        start:{dateTime:start.toISOString()},
        end:{dateTime:end.toISOString()},
        extendedProperties:{private:{booking_id:"PENDING"}}
      });
    }

    // Create booking and its per-slot capacity records.
    const {data:booking,error:be}=await sb.from("bookings").insert({
      location_id:loc.id,
      student_name:student.fullName.trim(),
      student_phone:student.phone.trim(),
      student_email:student.email.trim(),
      start_time:start.toISOString(),
      end_time:end.toISOString(),
      timezone:loc.timezone,
      status:"confirmed",
      google_event_id:googleEvent?.id || null,
      stripe_payment_status:loc.payment_required ? "pending" : "not_required"
    }).select("*").single();

    if(be) throw be;

    const slotRows=slots.map(s=>({...s,booking_id:booking.id,location_id:loc.id}));
    const {error:se}=await sb.from("booking_slots").insert(slotRows);
    if(se) {
      await sb.from("bookings").update({status:"cancelled"}).eq("id",booking.id);
      throw se;
    }

    // Update the Google event with the actual booking ID.
    if(gc && googleEvent) {
      const token=await getAccessToken(gc.refresh_token);
      await fetch(
        `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(gc.google_calendar_id)}/events/${encodeURIComponent(googleEvent.id)}`,
        {
          method:"PATCH",
          headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"},
          body:JSON.stringify({
            description:[
              `Booking ID: ${booking.id}`,
              `Student: ${student.fullName}`,
              `Phone: ${student.phone}`,
              `Email: ${student.email}`
            ].join("\n"),
            extendedProperties:{private:{booking_id:booking.id}}
          })
        }
      );
    }

    // Stripe is intentionally not implemented in this first version.
    // When payment_required=true, this function should instead create a Stripe
    // Checkout Session and return its URL, keeping the booking pending until
    // Stripe confirms payment via webhook.

    const manageUrl = `${Deno.env.get("PUBLIC_BOOKING_URL") || ""}/manage-booking.html?token=${encodeURIComponent(booking.booking_token)}`;

    return new Response(JSON.stringify({
      booking_id:booking.id,
      manage_url:manageUrl,
      checkout_url:null
    }), {headers:{...corsHeaders,"Content-Type":"application/json"}});
  } catch(e) {
    return new Response(JSON.stringify({error:e.message}),{
      status:400,headers:{...corsHeaders,"Content-Type":"application/json"}
    });
  }
});
