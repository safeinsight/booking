import { corsHeaders } from "../_shared/cors.ts";

Deno.serve(async req => {
  if(req.method==="OPTIONS") return new Response("ok",{headers:corsHeaders});

  const url=new URL(req.url);
  const locationId=url.searchParams.get("location_id");
  if(!locationId) return new Response("Missing location_id",{status:400,headers:corsHeaders});

  const redirectUri=`${Deno.env.get("SUPABASE_URL")}/functions/v1/google-oauth-callback`;
  const oauth=new URL("https://accounts.google.com/o/oauth2/v2/auth");
  oauth.searchParams.set("client_id",Deno.env.get("GOOGLE_CLIENT_ID")!);
  oauth.searchParams.set("redirect_uri",redirectUri);
  oauth.searchParams.set("response_type","code");
  oauth.searchParams.set("access_type","offline");
  oauth.searchParams.set("prompt","consent");
  oauth.searchParams.set("scope","https://www.googleapis.com/auth/calendar");
  oauth.searchParams.set("state",locationId);

  return Response.redirect(oauth.toString(),302);
});
