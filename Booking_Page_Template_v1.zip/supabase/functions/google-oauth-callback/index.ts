import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const sb=createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

Deno.serve(async req=>{
  try {
    const url=new URL(req.url);
    const code=url.searchParams.get("code");
    const locationId=url.searchParams.get("state");
    if(!code||!locationId) throw new Error("Missing Google OAuth parameters.");

    const redirectUri=`${Deno.env.get("SUPABASE_URL")}/functions/v1/google-oauth-callback`;
    const body=new URLSearchParams({
      code,
      client_id:Deno.env.get("GOOGLE_CLIENT_ID")!,
      client_secret:Deno.env.get("GOOGLE_CLIENT_SECRET")!,
      redirect_uri:redirectUri,
      grant_type:"authorization_code"
    });

    const tokenRes=await fetch("https://oauth2.googleapis.com/token",{
      method:"POST",
      headers:{"Content-Type":"application/x-www-form-urlencoded"},
      body
    });
    const tokens=await tokenRes.json();
    if(!tokenRes.ok) throw new Error(tokens.error_description || "Google token exchange failed.");
    if(!tokens.refresh_token) throw new Error("Google did not return a refresh token. Reconnect with consent.");

    // Determine the calendar used by the connected Google account.
    const calRes=await fetch("https://www.googleapis.com/calendar/v3/users/me/calendarList",{
      headers:{Authorization:`Bearer ${tokens.access_token}`}
    });
    const calendars=await calRes.json();
    if(!calRes.ok) throw new Error(calendars.error?.message || "Could not read calendars.");

    const primary=calendars.items?.find((c:any)=>c.primary) || calendars.items?.[0];
    if(!primary) throw new Error("No Google Calendar was found.");

    await sb.from("google_calendar_connections").upsert({
      location_id:locationId,
      google_calendar_id:primary.id,
      refresh_token:tokens.refresh_token,
      connected_email:primary.summaryOverride || primary.summary,
      updated_at:new Date().toISOString()
    });

    const adminUrl=Deno.env.get("BOOKING_ADMIN_URL") || "/";
    return Response.redirect(`${adminUrl}?google=connected`,302);
  } catch(e) {
    return new Response(`Google Calendar connection failed: ${e.message}`,{status:400});
  }
});
