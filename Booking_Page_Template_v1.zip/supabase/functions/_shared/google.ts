const GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token";
const GOOGLE_API = "https://www.googleapis.com/calendar/v3";

export async function getAccessToken(refreshToken: string): Promise<string> {
  const body = new URLSearchParams({
    client_id: Deno.env.get("GOOGLE_CLIENT_ID")!,
    client_secret: Deno.env.get("GOOGLE_CLIENT_SECRET")!,
    refresh_token: refreshToken,
    grant_type: "refresh_token"
  });

  const r = await fetch(GOOGLE_TOKEN_URL, {
    method: "POST",
    headers: {"Content-Type": "application/x-www-form-urlencoded"},
    body
  });
  const data = await r.json();
  if (!r.ok) throw new Error(data.error_description || "Google token refresh failed.");
  return data.access_token;
}

export async function listEvents(
  accessToken: string, calendarId: string, timeMin: string, timeMax: string
) {
  const url = new URL(`${GOOGLE_API}/calendars/${encodeURIComponent(calendarId)}/events`);
  url.searchParams.set("timeMin", timeMin);
  url.searchParams.set("timeMax", timeMax);
  url.searchParams.set("singleEvents", "true");
  url.searchParams.set("orderBy", "startTime");
  url.searchParams.set("showDeleted", "false");
  url.searchParams.set("maxResults", "2500");

  const r = await fetch(url, {headers: {Authorization: `Bearer ${accessToken}`}});
  const data = await r.json();
  if (!r.ok) throw new Error(data.error?.message || "Google Calendar read failed.");
  return data.items || [];
}

export async function createEvent(
  accessToken: string, calendarId: string, event: Record<string, unknown>
) {
  const r = await fetch(
    `${GOOGLE_API}/calendars/${encodeURIComponent(calendarId)}/events`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(event)
    }
  );
  const data = await r.json();
  if (!r.ok) throw new Error(data.error?.message || "Google Calendar event creation failed.");
  return data;
}

export async function updateEvent(
  accessToken: string, calendarId: string, eventId: string, event: Record<string, unknown>
) {
  const r = await fetch(
    `${GOOGLE_API}/calendars/${encodeURIComponent(calendarId)}/events/${encodeURIComponent(eventId)}`,
    {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(event)
    }
  );
  const data = await r.json();
  if (!r.ok) throw new Error(data.error?.message || "Google Calendar event update failed.");
  return data;
}

export async function deleteEvent(
  accessToken: string, calendarId: string, eventId: string
) {
  const r = await fetch(
    `${GOOGLE_API}/calendars/${encodeURIComponent(calendarId)}/events/${encodeURIComponent(eventId)}`,
    {method: "DELETE", headers: {Authorization: `Bearer ${accessToken}`}}
  );
  if (!r.ok && r.status !== 410 && r.status !== 404) {
    const data = await r.json().catch(() => ({}));
    throw new Error(data.error?.message || "Google Calendar event deletion failed.");
  }
}
