import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "../_shared/cors.ts";
import { getAccessToken, listEvents } from "../_shared/google.ts";

const sb = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

function isoAt(date: string, time: string, tz: string) {
  // The production version should use a timezone-aware library if locations span
  // unusual DST boundaries. For common US time zones, use the Temporal polyfill
  // or replace this helper with your preferred timezone utility.
  return new Date(`${date}T${time}:00`).toISOString();
}

function dayLabel(date: string) {
  return new Intl.DateTimeFormat("en-US", {
    weekday:"long", month:"short", day:"numeric"
  }).format(new Date(`${date}T12:00:00Z`));
}

function dateOnly(d: Date) {
  return d.toISOString().slice(0,10);
}

function overlaps(aStart:string,aEnd:string,bStart:string,bEnd:string) {
  return new Date(aStart) < new Date(bEnd) && new Date(aEnd) > new Date(bStart);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", {headers:corsHeaders});

  try {
    const url = new URL(req.url);
    const slug = url.searchParams.get("location");
    if (!slug) throw new Error("Missing location.");

    const {data: location, error: le} = await sb
      .from("locations").select("*").eq("slug",slug).eq("active",true).single();
    if (le || !location) throw new Error("Location not found.");

    const {data: rules} = await sb.from("availability_rules")
      .select("*").eq("location_id",location.id).eq("enabled",true);

    const today = new Date();
    const horizon = new Date(today.getTime() + location.booking_horizon_days * 86400000);
    const minimum = new Date(today.getTime() + location.minimum_booking_notice_hours * 3600000);

    let googleEvents:any[] = [];
    const {data: gc} = await sb.from("google_calendar_connections")
      .select("google_calendar_id,refresh_token").eq("location_id",location.id).maybeSingle();

    if (gc) {
      const token = await getAccessToken(gc.refresh_token);
      googleEvents = await listEvents(token, gc.google_calendar_id, minimum.toISOString(), horizon.toISOString());
    }

    // Booking events created by this system carry extendedProperties.private.booking_id.
    // Any other Google event is treated as a blocking event.
    const blockingEvents = googleEvents.filter(e => !e.extendedProperties?.private?.booking_id);

    const {data: bookingSlots} = await sb.from("booking_slots")
      .select("slot_start,slot_end,booking_id,bookings!inner(status)")
      .eq("location_id",location.id)
      .gte("slot_start", minimum.toISOString())
      .lt("slot_start", horizon.toISOString())
      .in("bookings.status",["pending","confirmed","rescheduled"]);

    const days:any[] = [];
    const startDate = new Date(dateOnly(minimum) + "T00:00:00Z");
    const endDate = new Date(dateOnly(horizon) + "T00:00:00Z");

    for (let d = new Date(startDate); d <= endDate; d.setUTCDate(d.getUTCDate()+1)) {
      const date = dateOnly(d);
      const dow = d.getUTCDay();
      const dayRules = (rules || []).filter(r => r.day_of_week === dow);
      const slots:any[] = [];

      for (const rule of dayRules) {
        const slotMinutes = location.appointment_length_minutes;
        let cursor = new Date(isoAt(date, rule.start_time, location.timezone));
        const end = new Date(isoAt(date, rule.end_time, location.timezone));

        while (cursor < end) {
          const slotEnd = new Date(cursor.getTime() + slotMinutes*60000);
          if (slotEnd > end) break;

          const startIso = cursor.toISOString(), endIso = slotEnd.toISOString();
          const blocking = blockingEvents.some(e => {
            const s = e.start?.dateTime || (e.start?.date ? `${e.start.date}T00:00:00Z` : null);
            const en = e.end?.dateTime || (e.end?.date ? `${e.end.date}T00:00:00Z` : null);
            return s && en && overlaps(startIso,endIso,s,en);
          });

          const booked = (bookingSlots || []).filter(b =>
            overlaps(startIso,endIso,b.slot_start,b.slot_end)
          ).length;

          slots.push({
            start:startIso,
            end:endIso,
            blocked,
            booked,
            remaining: Math.max(0, location.max_students_per_slot - booked)
          });

          cursor = slotEnd;
        }
      }

      // Deduplicate slots and sort.
      const unique = [...new Map(slots.map(s => [s.start,s])).values()]
        .sort((a,b) => new Date(a.start).getTime()-new Date(b.start).getTime());

      days.push({
        date,
        label:dayLabel(date),
        has_available: unique.some(s => !s.blocked && s.remaining > 0),
        slots:unique
      });
    }

    return new Response(JSON.stringify({
      location:{
        slug:location.slug,name:location.name,
        timezone:location.timezone,
        max_students_per_slot:location.max_students_per_slot
      },
      days
    }), {headers:{...corsHeaders,"Content-Type":"application/json"}});
  } catch (e) {
    return new Response(JSON.stringify({error:e.message}), {
      status:400, headers:{...corsHeaders,"Content-Type":"application/json"}
    });
  }
});
